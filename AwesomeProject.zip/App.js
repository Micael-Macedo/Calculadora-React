import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Button } from 'react-native';

export default function App() {
  const [display, displaySet] = useState(0)

  function tecla(valor) {
    displaySet(valor)
  }
  return (
    <View style={{
      width: 200,
      alignSelf: 'center',
      alignItems: 'center',
      borderColor: 'purple',
      backgroundColor: 'grey',
      borderWidth: 2,
      padding: 5,
      borderRadius: 10,
      margin: 50,
    }}>
      <View style={{
        alignItems: 'center',
        justifyContent: 'center',
      }}>
        <Text>{display}</Text>
      </View>
      <View style={{
        flexDirection: 'row',
        margin: 5,

      }}>
        <Button title='1' onPress={() => tecla(1)} />
        <Button title='2' onPress={() => tecla(2)} />
        <Button title='3' onPress={() => tecla(3)} />
        <Button title='+' onPress={() => tecla("+")} />
      </View>
      <View style={{
        flexDirection: 'row',
        margin: 5,

      }}>
        <Button title='4' onPress={() => tecla(4)} />
        <Button title='5' onPress={() => tecla(5)} />
        <Button title='6' onPress={() => tecla(6)} />
        <Button title='-' onPress={() => tecla("-")} />
      </View>
      <View style={{
        flexDirection: 'row',
        margin: 5,

      }}>
        <Button title='7' onPress={() => tecla(7)} />
        <Button title='8' onPress={() => tecla(8)} />
        <Button title='9' onPress={() => tecla(9)} />
        <Button title='x' onPress={() => tecla("x")} />
      </View>
      <View style={{
        flexDirection: 'row',
        margin: 5,

      }}>
        <Button title='c' onPress={() => tecla(0)} />
        <Button title='0' onPress={() => tecla("0")} />
        <Button title='=' onPress={() => tecla("=")} />
        <Button title='/' onPress={() => tecla("/")} />
      </View>


    </View>
  );
}


